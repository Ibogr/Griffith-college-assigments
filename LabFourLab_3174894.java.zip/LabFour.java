package griffith;


     //3174894\\
//<IBRAHIM GURSES>\\

import java.util.Arrays;
import java.util.Scanner;

import javafx.concurrent.Task;

public class LabFour {
	public static void main(String[] args) {

		// Task one

		// Test the method with a sample array

		String[] originalArray = { "this", "is", "the", "final" };
		// Giving string and store it

		String[] result = reverse(originalArray);
		// reverse the original array by using reverse method.

		System.out.println(Arrays.toString(result));
		// Output of result variable after change to string.

		// Task two

		Scanner scanner = new Scanner(System.in);
		// scanner class let in the system.

		System.out.println("How many grade would you like to enter (1-9) :");
		// Ask to user how many grades want to calculate with.

		int scan = scanner.nextInt();
		// store the first fetched data from user to the variable.

		int[] array = new int[scan];
		// store the data from scan (by doing that array variable will become as count
		// as user entered)
		// to variable called array data type int and defined 1D array by "[]".

		for (int i = 0; i < scan; i++) {
			// loop throught scan that fetch data from user.

			System.out.println("What is your " + (+i + 1) + " grade :");
			// Ask user the grade that wants to enter and track the question number by
			// incrementing the index 1 by 1.

			array[i] += scanner.nextInt();
			// store the next value user entered to the next address of the array.
		}
		Arrays.sort(array);
		// Aplling sort in orderto find max and lowest value.

		int highest = array[array.length - 1];
		// An empty variable started counting 0.

		int lowest = array[0];
		// An empty variable started counting 0.

		countMethod(array);
		// calling the method count above and below.

		System.out.println("The highest value in the array: " + highest);
		System.out.println("The lowest value in the array: " + lowest);
		System.out.println("average of the grades: " + calculateAverage(array));
		System.out.println("median of the grades: " + calculateMedian(array));
		// print all method and variable the programe have.

		// Task three

		// Input array to separate into primes and non-primes
		int[] arr = { 4, 7, 13, 6, 19, 5, 12, 21 };

		// Call the method to get the result
		int[][] result1 = separatePrimesAndNonPrimes(arr);

		// Print the result
		System.out.println(Arrays.deepToString(result1));
	}

	static String[] reverse(String[] array) {
		// this method for revers the original string and takes one parameter.

		String[] reversedArray = new String[array.length];
		// create new array and assign it to a variable.

		for (int i = 0; i < array.length; i++) {
			reversedArray[i] = array[array.length - 1 - i];
			// loop trought the array by using lenght atribute that create as a parameter
			// and starts counting end of the array by decreasing.
		}

		return reversedArray;
		// return the string (it must have because mathod type requires.
	}

	static void countMethod(int[] array) {
		// this method counts average, above, below and failed as demanded.
		int average = calculateAverage(array);
		// local variable

		int above = 0;
		// An empty variable started counting 0.

		int below = 0;
		// An empty variable started counting 0.

		int failed = 0;
		// An empty variable started counting 0.

		for (int i : array) {
			// loop through array.

			if (i < average) {
				// fetch the whatever 'i' below the average

				below++;
				// increment variable named below 1 by 1 if the condition true.
			} else {
				// if block doesn't work apply this else block.

				above++;
				// increment variable named above if the first condition does't work.

			}
			if (i < 40) {
				failed++;
			}
		}
		System.out.println("there are " + above + " above the average");
		System.out.println("there are " + below + " below the average");
		System.out.println("there are " + failed + " people");
	}

	static double calculateMedian(int[] array) {
		// this method calculates median of given array and returns double type
		double median = 0;
		// An empty variable started counting 0.

		for (int i = 0; i < array.length; i++) {
			// loop through array and returns indexes of array.
			if (array.length % 2 == 0) {
				// to check the length of array if its even or odd.

				int median1 = array.length / 2;
				// divide by 2 of length of array.

				int median2 = median1 - 1;
				// store value that substracted by 1 to find a second number.

				median = (array[median1] + array[median2]) / 2.0;
				// assign new value that founded by adding and by dividing two value middile of
				// the array.
			} else {
				median = array[array.length / 2];
				// if the array odd just simple to find a middle number of the array.
			}
		}

		return median;
		// return value that assigned
	}

	static int calculateAverage(int[] array) {
		// this method calculates average of an array.

		int sum = 0;
		int average = 0;

		for (int i = 0; i < array.length; i++) {
			sum += array[i];
			average = sum / array.length;
		}
		return average;
	}

	public static int[][] separatePrimesAndNonPrimes(int[] arr) {
		// Array of numbers to separate into primes and non-primes
		int[] tempPrimes = new int[arr.length];
		int[] tempNonPrimes = new int[arr.length];
		int primeCount = 0; // Counter for prime numbers
		int nonPrimeCount = 0; // Counter for non-prime numbers

		// Loop through each number in the input array
		for (int num : arr) {
			boolean isPrime = true; // Assume the number is prime

			// Check divisibility from 2 to the square root of the number
			int squareRoot = (int) Math.sqrt(num);
			for (int i = 2; i <= squareRoot; i++) {
				if (num % i == 0) {
					// If divisible, it's not a prime number
					isPrime = false;
					break; // Exit the loop as we know it's not prime
				}
			}

			if (isPrime) {
				// Separate numbers into primes and non-primes
				tempPrimes[primeCount++] = num; // Add to primes and increment the prime counter
			} else {
				tempNonPrimes[nonPrimeCount++] = num; // Add to non-primes and increment the non-prime counter
			}
		}

		int[] primes = new int[primeCount]; // Array to hold only primes
		int[] nonPrimes = new int[nonPrimeCount]; // Array to hold only non-primes

		// Copy values from temporary arrays to final arrays
		System.arraycopy(tempPrimes, 0, primes, 0, primeCount);
		System.arraycopy(tempNonPrimes, 0, nonPrimes, 0, nonPrimeCount);

		// Create a 2D array to store both prime and non-prime arrays
		int[][] result = new int[2][];
		result[0] = primes;
		result[1] = nonPrimes;

		// Return the 2D array
		return result;
	}
}
