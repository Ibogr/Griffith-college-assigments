package griffith;

   //3174894\\
//IBRAHIM GURSES\\

import java.util.Random;
import java.util.Scanner;

public class LabThree {

    public static void main(String[] args) {
        // Create a Scanner object to read user input
        Scanner scanner = new Scanner(System.in);

        // Task 1 - Prompt user for a string and count digits, vowels, and consonants in it
        System.out.print("Enter a string: ");
        // Read the user's input string
        String input = scanner.nextLine();  

        // Call methods to count digits, vowels, and consonants
        int countNumber = countDigits(input);    
        int countVowel = countVowels(input);    
        int countConsonants = countConsonants(input);

        // print out the results of each count
        System.out.println("Digits: " + countNumber);
        System.out.println("Vowels: " + countVowel);
        System.out.println("Consonants: " + countConsonants);
        System.out.println("Length: " + input.length());
        
        //Separator
        System.out.println("\n");
        
        //task two - Generate Password
        String passwordGenerator= generatePassword();
        System.out.println("Your secure password is: " + passwordGenerator);
        
        //Separator
        System.out.println("\n");
        
        // Task 3 - Password Validation
        boolean validPassword = false;

        // Loop to keep asking for a valid password until it satisfies all conditions
        while (!validPassword) {
            System.out.print("Enter password: ");
            // Read password input
            String password = scanner.nextLine(); 

            // Call method to validate the password
            validPassword = validatePassword(password);

            // Check if the password is valid and print the result
            if (validPassword) {
                System.out.println("Password accepted: " + password);
            } else {
                System.out.println("Please try again.\n");
            }
        }

        // Close the scanner resource
        scanner.close();
    }

    // Method to count digits in the given string
    public static int countDigits(String sentence) {
        int count = 0;
        // Loop through each character of the string
        for (char i : sentence.toCharArray()) {
            // Check if the character is a digit
            if (Character.isDigit(i)) {
                count++;
            }
        }
        // Return the total count of digits
        return count;
    }

    // Method to count vowels in the given string
    public static int countVowels(String sentence) {
        int count = 0;
        // create a string conteins vowels letter
        String vowels = "aeiouAEIOU"; 
        // Loop through each character of the string
        for (char i : sentence.toCharArray()) {
            // Check if the character is a vowel
            if (vowels.indexOf(i) != -1) {
                count++; 
            }
        }
        // Return the total count of vowels
        return count;
    }

    // Method to count consonants in the given string
    public static int countConsonants(String sentence) {
        int count = 0;
        String vowels = "aeiouAEIOU"; 
        // Loop through each character of the string
        for (char i : sentence.toCharArray()) {
            // Check if the character is a letter and not a vowel
            if (Character.isLetter(i) && vowels.indexOf(i) == -1) {
            	// Increment count if the character is a consonant
                count++;  
            }
        }
        return count;  // Return the total count of consonants
    }

    // Method to validate the password according to the required rules
    public static boolean validatePassword(String password) {
        // Define the criteria for a valid password
        final int requiredUpperCase = 1; 
        final int requiredLowerCase = 1; 
        final int requiredDigits = 2;   
        final int minLength = 8;          

        int upperCaseCount = 0;
        int lowerCaseCount = 0;
        int digitCount = 0;

        // Loop through each character of the password
        for (char letter : password.toCharArray()) {
            // Check if the character is uppercase, lowercase, or a digit
            if (Character.isUpperCase(letter)) {
                upperCaseCount++;
            } else if (Character.isLowerCase(letter)) {
                lowerCaseCount++;
            } else if (Character.isDigit(letter)) {
                digitCount++;
            }
        }
        boolean hasSymbols = false;

        // Check if the password contains at least one special character from the list
        if (password.contains("&") || password.contains("$") || password.contains("%") || password.contains("#")) {
        	hasSymbols = true;
        }

        // Validate if all criteria are met for a valid password
        boolean isValid = upperCaseCount >= requiredUpperCase &&
                          lowerCaseCount >= requiredLowerCase &&
                          digitCount >= requiredDigits &&
                          password.length() >= minLength &&
                          hasSymbols;

        // If the password is not valid, print the reasons why
        if (!isValid) {
            if (upperCaseCount < requiredUpperCase) {
                System.out.println("Password must have at least one uppercase letter.");
            }
            if (lowerCaseCount < requiredLowerCase) {
                System.out.println("Password must have at least one lowercase letter.");
            }
            if (digitCount < requiredDigits) {
                System.out.println("Password must have at least two digits.");
            }
            if (password.length() < minLength) {
                System.out.println("Password must be at least 8 characters long.");
            }
            if (!hasSymbols) {
                System.out.println("Password must contain at least one of the following symbols: (&, $, %, #)");
            }
        }
         // Return true if the password is valid, false otherwise this return must be in it because of method created as an int kind.
        return isValid;  
    }
    
    // Method to generate a secure password
    public static String generatePassword() {
    	// create random object from the random class.
        Random random = new Random();
        //create an object from stringBuilder class to store randomly selected letter, numbers and symbols.
        StringBuilder passwordBuilder = new StringBuilder();
        
        // Generate a random uppercase letter (A-Z)
        //nextInt creates 0-25 numbers randomly and assigns the number to ASCII character starts at 65 which starts uppercase letter "A".
        char randomUppercase = (char) (random.nextInt(26) + 65);
        
        // Generate a random lowercase letter (a-z)
        //nextInt creates 0-25 numbers randomly and assigns the number to ASCII character starts at 97 which starts uppercase letter "A".
        char randomLowercase = (char) (random.nextInt(26) + 97);
        
        // Define a string of symbols to choose from
        String symbol = "%£&$";
        
        // Pick a random symbol from the predefined symbols string
        char randomSymbol = symbol.charAt(random.nextInt(symbol.length()));
        
        // Add 2 random digits to the password
        for (int i = 0; i < 2; i++) {
        	//nextInt creates 0-9 numbers randomly and assigns the number to ASCII character starts at 48 which starts 0 to 9.
            char randomDigit = (char) (random.nextInt(10) + 48);
            passwordBuilder.append(randomDigit);
        }
        
        // Add the randomly selected uppercase, lowercase, and symbol
        passwordBuilder.append(randomUppercase);
        passwordBuilder.append(randomLowercase);
        passwordBuilder.append(randomSymbol);
        
        // cheack the password is at least 8 characters long
        while (passwordBuilder.length() < 8) {
        	// choice variable stores 4 randomly selected numbers.
            int choice = random.nextInt(4);
            /*switch case, gives a reaction and append to passwordBulder where is get 
             * together all picked values randomly in case of selected numbers by choice*/
            switch (choice) {
                case 0 -> passwordBuilder.append((char) (random.nextInt(26) + 65));  
                case 1 -> passwordBuilder.append((char) (random.nextInt(26) + 97));  
                case 2 -> passwordBuilder.append((char) (random.nextInt(10) + 48)); 
                case 3 -> passwordBuilder.append(symbol.charAt(random.nextInt(symbol.length()))); 
            }
        }
        
        // Convert StringBuilder to String and return the generated password
        return passwordBuilder.toString();
    }

}
